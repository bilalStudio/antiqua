import React from 'react'

import PropTypes from 'prop-types'

import './tab-power-search.css'

const TabPowerSearch = (props) => {
  return (
    <div className={`tab-power-search-container ${props.rootClassName} `}>
      <div className="tab-power-search-web-tab-div">
        <span className="tab-power-search-web-tab-text">{props.Web1}</span>
        <img
          alt={props.image_alt}
          src={props.image_src}
          className="tab-power-search-selection-underline"
        />
      </div>
      <div className="tab-power-search-notizie-tab-div">
        <span className="tab-power-search-notizie-tab-text">
          {props.Notizie}
        </span>
      </div>
      <div className="tab-power-search-aziende-tab-div">
        <span className="tab-power-search-aziende-text">{props.Aziende}</span>
      </div>
      <div className="tab-power-search-video-tab-div">
        <span className="tab-power-search-video-tab-text">{props.Video}</span>
      </div>
      <div className="tab-power-search-social-tab-div">
        <span className="tab-power-search-social-text">{props.Social}</span>
      </div>
      <div className="tab-power-search-prodotti-tab-div">
        <span className="tab-power-search-prodotti-text">{props.Prodotti}</span>
      </div>
    </div>
  )
}

TabPowerSearch.defaultProps = {
  Social: 'Social',
  Web1: 'Web',
  Aziende: 'Aziende',
  image_alt: 'image',
  Video: 'Video',
  rootClassName: '',
  Prodotti: 'Prodotti',
  Notizie: 'Notizie',
  image_src: '/playground_assets/line%201.svg',
}

TabPowerSearch.propTypes = {
  Social: PropTypes.string,
  Web1: PropTypes.string,
  Aziende: PropTypes.string,
  image_alt: PropTypes.string,
  Video: PropTypes.string,
  rootClassName: PropTypes.string,
  Prodotti: PropTypes.string,
  Notizie: PropTypes.string,
  image_src: PropTypes.string,
}

export default TabPowerSearch
