import React from 'react'

import PropTypes from 'prop-types'

import './search-bar1.css'

const SearchBar1 = (props) => {
  return (
    <div className={`search-bar1-container ${props.rootClassName} `}>
      <div className="search-bar1-search-bar-main-div">
        <div className="search-bar1-search-div">
          <span className="search-bar1-searc-text">
            <span className="">Cerca</span>
            <br className=""></br>
          </span>
        </div>
        <div className="search-bar1-delete-search-div">
          <img
            alt={props.image_alt}
            src={props.image_src}
            className="search-bar1-delete-icon"
          />
          <div className="search-bar1-search-icon-div">
            <img
              alt={props.image_alt1}
              src={props.image_src1}
              className="search-bar1-search-icon"
            />
          </div>
        </div>
      </div>
    </div>
  )
}

SearchBar1.defaultProps = {
  image_src: '/playground_assets/backspace-delete-button%201.svg',
  rootClassName: '',
  image_alt1: 'image',
  image_src1: '/playground_assets/group%202.svg',
  image_alt: 'image',
}

SearchBar1.propTypes = {
  image_src: PropTypes.string,
  rootClassName: PropTypes.string,
  image_alt1: PropTypes.string,
  image_src1: PropTypes.string,
  image_alt: PropTypes.string,
}

export default SearchBar1
