import React from 'react'

import './password-dimenticata-step2.css'

const PasswordDimenticataStep2 = (props) => {
  return (
    <div className="password-dimenticata-step2-password-dimenticata-step2">
      <div className="password-dimenticata-step2-deletedisabled1">
        <div className="password-dimenticata-step2-group">
          <img
            src="/playground_assets/vector6392-28e.svg"
            alt="Vector6392"
            className="password-dimenticata-step2-vector"
          />
          <img
            src="/playground_assets/vector6392-lgqd.svg"
            alt="Vector6392"
            className="password-dimenticata-step2-vector1"
          />
        </div>
      </div>
      <span className="password-dimenticata-step2-password-text1">
        <span>Password dimenticata?</span>
      </span>
      <span className="password-dimenticata-step2-password-text2">
        <span>
          <span>Inserisci una mail a cui inviare il codice di recupero.</span>
          <br></br>
          <span>Mi raccomando non condividere a nessuno questo codice</span>
        </span>
      </span>
      <div className="password-dimenticata-step2-inputdiv1">
        <div className="password-dimenticata-step2-frame33">
          <span className="password-dimenticata-step2-text05">
            <span>Email</span>
          </span>
        </div>
        <div className="password-dimenticata-step2-frame31">
          <span className="password-dimenticata-step2-text07">
            <span>mario@rossi.it</span>
          </span>
        </div>
      </div>
      <div className="password-dimenticata-step2-inputdiv2">
        <div className="password-dimenticata-step2-frame331">
          <span className="password-dimenticata-step2-text09">
            <span>Codice</span>
          </span>
        </div>
        <div className="password-dimenticata-step2-frame311">
          <span className="password-dimenticata-step2-text11">
            <span>*********</span>
          </span>
        </div>
      </div>
      <div className="password-dimenticata-step2-button1div">
        <span className="password-dimenticata-step2-text13">
          <span>Prosegui</span>
        </span>
      </div>
    </div>
  )
}

export default PasswordDimenticataStep2
