import React from 'react'

import './products-filter.css'

const ProductsFilter = (props) => {
  return (
    <div className="products-filter-products-filter">
      <span>
        <span>Ordina per:</span>
      </span>
      <span className="products-filter-text2">
        <span className="products-filter-text1">Reset filtri</span>
      </span>
      <div className="products-filter-button-order-for">
        <span className="products-filter-text3">Meno costoso</span>
        <img
          src="/playground_assets/arrowdown1i120-hwwd.svg"
          alt="arrowdown1I120"
          className="products-filter-arrowdown1"
        />
      </div>
    </div>
  )
}

export default ProductsFilter
