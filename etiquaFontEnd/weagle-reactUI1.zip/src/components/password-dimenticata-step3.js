import React from 'react'

import './password-dimenticata-step3.css'

const PasswordDimenticataStep3 = (props) => {
  return (
    <div className="password-dimenticata-step3-password-dimenticata-step3">
      <div className="password-dimenticata-step3-deletedisabled1">
        <div className="password-dimenticata-step3-group">
          <img
            src="/playground_assets/vector6392-zuno.svg"
            alt="Vector6392"
            className="password-dimenticata-step3-vector"
          />
          <img
            src="/playground_assets/vector6392-74wo.svg"
            alt="Vector6392"
            className="password-dimenticata-step3-vector1"
          />
        </div>
      </div>
      <span className="password-dimenticata-step3-psws3t1">
        <span>Crea nuova password</span>
      </span>
      <span className="password-dimenticata-step3-psws3t12">
        <span>Crea una nuova password</span>
      </span>
      <div className="password-dimenticata-step3-input1">
        <div className="password-dimenticata-step3-frame33">
          <span className="password-dimenticata-step3-text02">
            <span>Password</span>
          </span>
        </div>
        <div className="password-dimenticata-step3-frame31">
          <span className="password-dimenticata-step3-text04">
            <span>*************************</span>
          </span>
        </div>
      </div>
      <div className="password-dimenticata-step3-input2">
        <div className="password-dimenticata-step3-frame331">
          <span className="password-dimenticata-step3-text06">
            <span>Ripeti password</span>
          </span>
        </div>
        <div className="password-dimenticata-step3-frame311">
          <span className="password-dimenticata-step3-text08">
            <span>*************************</span>
          </span>
        </div>
      </div>
      <div className="password-dimenticata-step3-button-change-password">
        <span className="password-dimenticata-step3-text10">
          <span>Salva nuova password</span>
        </span>
      </div>
    </div>
  )
}

export default PasswordDimenticataStep3
