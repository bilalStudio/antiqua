import React from 'react'

import PropTypes from 'prop-types'

import './video-search-result.css'

const VideoSearchResult = (props) => {
  return (
    <div className="video-search-result-container">
      <div className="video-search-result-video-result-div">
        <div className="video-search-result-video-result-image"></div>
        <div className="video-search-result-video-result-link-title-description">
          <span className="video-search-result-video-result-link">
            {props.linkYoutubeResult}
          </span>
          <span className="video-search-result-video-result-title">
            {props.TitleYoutubeResult}
          </span>
          <span className="video-search-result-video-result-description">
            {props.DescriptionYoutubeResult}
          </span>
        </div>
        <div className="video-search-result-video-result-icon-div">
          <img
            alt={props.image_alt}
            src={props.image_src}
            className="video-search-result-video-result-icon"
          />
        </div>
      </div>
    </div>
  )
}

VideoSearchResult.defaultProps = {
  rootClassName: '',
  image_src: '/playground_assets/share.1%203.svg',
  TitleYoutubeResult: 'Juventus',
  linkYoutubeResult: 'https://it.wikipedia.org › wiki › Serie_A',
  image_alt: 'image',
  DescriptionYoutubeResult:
    "10 ore fa — Il Campionato di Serie A, colloquialmente abbreviato in Serie A e ufficialmente denominato Serie A TIM dall'edizione 1998-1999 per ragioni di ...",
}

VideoSearchResult.propTypes = {
  rootClassName: PropTypes.string,
  image_src: PropTypes.string,
  TitleYoutubeResult: PropTypes.string,
  linkYoutubeResult: PropTypes.string,
  image_alt: PropTypes.string,
  DescriptionYoutubeResult: PropTypes.string,
}

export default VideoSearchResult
