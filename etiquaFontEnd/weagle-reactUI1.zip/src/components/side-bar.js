import React from 'react'

import PropTypes from 'prop-types'

import './side-bar.css'

const SideBar = (props) => {
  return (
    <div className={`side-bar-container ${props.rootClassName} `}>
      <span className="side-bar-logo">{props.Weagle}</span>
      <div className="side-bar-power-search-div">
        <img
          alt={props.image_alt}
          src={props.image_src}
          className="side-bar-search-icon"
        />
        <span className="side-bar-power-search-text">Power Search</span>
      </div>
      <div className="side-bar-my-feed-div">
        <img
          alt={props.image_alt1}
          src={props.image_src1}
          className="side-bar-feed-icon"
        />
        <span className="side-bar-feed-text">
          <span className="">Il mio feed</span>
          <br className=""></br>
        </span>
      </div>
      <div className="side-bar-archivio-main-div">
        <img
          alt={props.image_alt13}
          src={props.image_src13}
          className="side-bar-archivio-icon"
        />
        <span className="side-bar-archivio-text">
          <span className="">Archivio</span>
          <br className=""></br>
        </span>
      </div>
      <div className="side-bar-data-walletmain-div">
        <img
          alt={props.image_alt12}
          src={props.image_src12}
          className="side-bar-wallet-icon"
        />
        <span className="side-bar-wallet-text">
          <span className="">My Data</span>
          <br className=""></br>
        </span>
      </div>
      <div className="side-bar-welfare-main-div">
        <img
          alt={props.image_alt11}
          src={props.image_src11}
          className="side-bar-welfare-icon"
        />
        <span className="side-bar-welfare-text">
          <span className="">Welfare</span>
          <br className=""></br>
        </span>
      </div>
    </div>
  )
}

SideBar.defaultProps = {
  image_src1: '/playground_assets/messages-chat-text%201.svg',
  image_src12: '/playground_assets/lock-protection-checkmark%201.svg',
  Weagle: 'Weagle',
  image_alt13: 'image',
  image_src11: '/playground_assets/heart-checkmark%201.svg',
  image_alt11: 'image',
  image_alt12: 'image',
  image_alt: 'image',
  rootClassName: '',
  image_src13: '/playground_assets/bookmarks%201.svg',
  image_alt1: 'image',
  image_src: '/playground_assets/group%201.svg',
}

SideBar.propTypes = {
  image_src1: PropTypes.string,
  image_src12: PropTypes.string,
  Weagle: PropTypes.string,
  image_alt13: PropTypes.string,
  image_src11: PropTypes.string,
  image_alt11: PropTypes.string,
  image_alt12: PropTypes.string,
  image_alt: PropTypes.string,
  rootClassName: PropTypes.string,
  image_src13: PropTypes.string,
  image_alt1: PropTypes.string,
  image_src: PropTypes.string,
}

export default SideBar
