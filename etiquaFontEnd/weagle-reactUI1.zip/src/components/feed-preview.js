import React from 'react'

import PropTypes from 'prop-types'

import './feed-preview.css'

const FeedPreview = (props) => {
  return (
    <div className={`feed-preview-container ${props.rootClassName} `}>
      <div className="feed-preview-container01">
        <div className="feed-preview-container02">
          <div className="feed-preview-container03">
            <img
              alt={props.image_alt1}
              src={props.image_src1}
              className="feed-preview-image"
            />
            <span className="feed-preview-text">{props.text4}</span>
          </div>
          <img
            alt={props.image_alt4}
            src={props.image_src4}
            className="feed-preview-image1"
          />
        </div>
      </div>
      <div className="feed-preview-container04">
        <div className="feed-preview-container05">
          <span className="feed-preview-text1">{props.text}</span>
        </div>
        <div className="feed-preview-container06">
          <img
            alt={props.image_alt}
            src={props.image_src}
            className="feed-preview-image2"
          />
        </div>
      </div>
      <div className="feed-preview-container07">
        <div className="feed-preview-container08">
          <span className="feed-preview-text2">{props.text3}</span>
        </div>
        <div className="feed-preview-container09">
          <img
            alt={props.image_alt3}
            src={props.image_src3}
            className="feed-preview-image3"
          />
        </div>
      </div>
      <div className="feed-preview-container10">
        <div className="feed-preview-container11">
          <span className="feed-preview-text3">{props.text2}</span>
        </div>
        <div className="feed-preview-container12">
          <img
            alt={props.image_alt2}
            src={props.image_src2}
            className="feed-preview-image4"
          />
        </div>
      </div>
      <div className="feed-preview-container13">
        <div className="feed-preview-container14">
          <span className="feed-preview-text4">{props.text1}</span>
        </div>
      </div>
    </div>
  )
}

FeedPreview.defaultProps = {
  rootClassName: '',
  image_alt3: 'image',
  image_alt4: 'image',
  image_src4: '/playground_assets/dots%201.svg',
  image_alt: 'image',
  image_src1: '/playground_assets/image%206-200h.png',
  text4: 'https://www.ilsole24ore.com/',
  image_src: '/playground_assets/rectangle%2017-200h.png',
  image_alt2: 'image',
  text2:
    'Nucleare, chi è per il sì e chi per il no. Cosa dicono i piani elettorali sull’energia...',
  image_src2: '/playground_assets/rectangle%2017-200h.png',
  image_alt1: 'image',
  text1: 'Copertura completa >',
  image_src3: '/playground_assets/rectangle%2017-200h.png',
  text: 'Nucleare, chi è per il sì e chi per il no. Cosa dicono i piani elettorali sull’energia...',
  text3:
    'Nucleare, chi è per il sì e chi per il no. Cosa dicono i piani elettorali sull’energia...',
}

FeedPreview.propTypes = {
  rootClassName: PropTypes.string,
  image_alt3: PropTypes.string,
  image_alt4: PropTypes.string,
  image_src4: PropTypes.string,
  image_alt: PropTypes.string,
  image_src1: PropTypes.string,
  text4: PropTypes.string,
  image_src: PropTypes.string,
  image_alt2: PropTypes.string,
  text2: PropTypes.string,
  image_src2: PropTypes.string,
  image_alt1: PropTypes.string,
  text1: PropTypes.string,
  image_src3: PropTypes.string,
  text: PropTypes.string,
  text3: PropTypes.string,
}

export default FeedPreview
