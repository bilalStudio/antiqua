import React from 'react'

import PropTypes from 'prop-types'

import './news-search-result-list.css'

const NewsSearchResultList = (props) => {
  return (
    <div className="news-search-result-list-container">
      <div className="news-search-result-list-news-maindiv">
        <div className="news-search-result-list-image-news-result">
          <img
            alt={props.image_alt1}
            src={props.image_src1}
            className="news-search-result-list-image"
          />
        </div>
        <div className="news-search-result-list-title-link-description-news">
          <span className="news-search-result-list-link-news">
            {props.linkNewsResult}
          </span>
          <span className="news-search-result-list-title-news">
            {props.TitleNewsResult}
          </span>
          <span className="news-search-result-list-description-news">
            {props.DescriptionNewsResult}
          </span>
        </div>
        <div className="news-search-result-list-share-div">
          <img
            alt={props.image_alt}
            src={props.image_src}
            className="news-search-result-list-share-icon"
          />
        </div>
      </div>
    </div>
  )
}

NewsSearchResultList.defaultProps = {
  image_alt: 'image',
  linkNewsResult: 'https://www.asromalive.it/',
  image_src1: '/playground_assets/group%2024.svg',
  DescriptionNewsResult:
    "La Roma continua a lavorare sulle uscite per l'arrivo di Andrea Belotti: ma scatta l'asta in Serie A per il 'Gallo'",
  image_alt1: 'image',
  TitleNewsResult:
    'Calciomercato Roma, asta Belotti in Serie A: doppio inserimento',
  image_src: '/playground_assets/share.1%203.svg',
}

NewsSearchResultList.propTypes = {
  image_alt: PropTypes.string,
  linkNewsResult: PropTypes.string,
  image_src1: PropTypes.string,
  DescriptionNewsResult: PropTypes.string,
  image_alt1: PropTypes.string,
  TitleNewsResult: PropTypes.string,
  image_src: PropTypes.string,
}

export default NewsSearchResultList
