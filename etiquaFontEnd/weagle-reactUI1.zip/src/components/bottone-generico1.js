import React from 'react'

import PropTypes from 'prop-types'

import './bottone-generico1.css'

const BottoneGenerico1 = (props) => {
  return (
    <div className={`bottone-generico1-container ${props.rootClassName} `}>
      <span className="bottone-generico1-testobottonegenerico">
        <span>Accedi al servizio</span>
        <br></br>
      </span>
    </div>
  )
}

BottoneGenerico1.defaultProps = {
  rootClassName: '',
}

BottoneGenerico1.propTypes = {
  rootClassName: PropTypes.string,
}

export default BottoneGenerico1
