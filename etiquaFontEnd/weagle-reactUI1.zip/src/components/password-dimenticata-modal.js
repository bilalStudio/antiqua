import React from 'react'

import './password-dimenticata-modal.css'

const PasswordDimenticataModal = (props) => {
  return (
    <div className="password-dimenticata-modal-password-dimenticata-main-div">
      <div className="password-dimenticata-modal-deletedisabled1">
        <div className="password-dimenticata-modal-group">
          <img
            src="/playground_assets/vector6392-46ch.svg"
            alt="Vector6392"
            className="password-dimenticata-modal-vector"
          />
          <img
            src="/playground_assets/vector6392-giz.svg"
            alt="Vector6392"
            className="password-dimenticata-modal-vector1"
          />
        </div>
      </div>
      <span className="password-dimenticata-modal-text">
        <span>Password dimenticata?</span>
      </span>
      <span className="password-dimenticata-modal-text02">
        <span>
          <span>Inserisci una mail a cui inviare il codice di recupero.</span>
          <br></br>
          <span>Mi raccomando non condividere a nessuno questo codice</span>
        </span>
      </span>
      <div className="password-dimenticata-modal-divmail">
        <div className="password-dimenticata-modal-frame33">
          <span className="password-dimenticata-modal-text07">
            <span>Email</span>
          </span>
        </div>
        <div className="password-dimenticata-modal-inputdiv">
          <span className="password-dimenticata-modal-text09">
            <span>mario@rossi.it</span>
          </span>
        </div>
      </div>
      <div className="password-dimenticata-modal-send-code-button">
        <span className="password-dimenticata-modal-text11">
          <span>Invia codice</span>
        </span>
      </div>
    </div>
  )
}

export default PasswordDimenticataModal
