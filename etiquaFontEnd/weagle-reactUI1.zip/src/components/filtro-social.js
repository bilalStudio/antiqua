import React from 'react'

import './filtro-social.css'

const FiltroSocial = (props) => {
  return (
    <div className="filtro-social-filtro-social">
      <div className="filtro-social-button-date">
        <span className="filtro-social-textdate">
          <span>Tutte le date</span>
        </span>
        <img
          src="/playground_assets/vector24371-gi5e.svg"
          alt="Vector24371"
          className="filtro-social-dropdownicon"
        />
      </div>
      <span className="filtro-social-reset-filters-button">
        <span>Reset filtri</span>
      </span>
      <div className="filtro-social-check-boxes-div">
        <div className="filtro-social-pagine-div">
          <img
            src="/playground_assets/rectangle564451-w29e-200h.png"
            alt="Rectangle564451"
            className="filtro-social-rectangle56"
          />
          <div className="filtro-social-frame21">
            <span className="filtro-social-text02">
              <span>Pagine</span>
            </span>
          </div>
        </div>
        <div className="filtro-social-gruppi-div">
          <img
            src="/playground_assets/rectangle574451-4dfl-200h.png"
            alt="Rectangle574451"
            className="filtro-social-rectangle57"
          />
          <div className="filtro-social-frame22">
            <span className="filtro-social-text04">
              <span>Gruppi</span>
            </span>
          </div>
        </div>
        <div className="filtro-social-post-div">
          <img
            src="/playground_assets/rectangle584451-9rdv-200h.png"
            alt="Rectangle584451"
            className="filtro-social-rectangle58"
          />
          <div className="filtro-social-frame23">
            <span className="filtro-social-text06">
              <span>Post</span>
            </span>
          </div>
        </div>
        <div className="filtro-social-eventi-div">
          <img
            src="/playground_assets/rectangle594451-lv59-200h.png"
            alt="Rectangle594451"
            className="filtro-social-rectangle59"
          />
          <div className="filtro-social-frame24">
            <span className="filtro-social-text08">
              <span>Eventi</span>
            </span>
          </div>
        </div>
      </div>
    </div>
  )
}

export default FiltroSocial
