import React from 'react'

import './date-filter-video.css'

const DateFilterVideo = (props) => {
  return (
    <div className="date-filter-video-date-filter-video">
      <span className="date-filter-video-datefilter-text">
        <span>Data</span>
      </span>
      <img
        src="/playground_assets/vector21751-a5cq.svg"
        alt="Vector21751"
        className="date-filter-video-dropdownicon"
      />
    </div>
  )
}

export default DateFilterVideo
