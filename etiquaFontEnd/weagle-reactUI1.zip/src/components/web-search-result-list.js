import React from 'react'

import PropTypes from 'prop-types'

import './web-search-result-list.css'

const WebSearchResultList = (props) => {
  return (
    <div className={`web-search-result-list-container ${props.rootClassName} `}>
      <div className="web-search-result-list-web-result-main-div">
        <div className="web-search-result-list-web-result-link-title-description-div">
          <span className="web-search-result-list-web-result-link">
            {props.LinkWebSearch1}
          </span>
          <span className="web-search-result-list-web-result-title">
            {props.DescriptionWebSearch}
          </span>
          <span className="web-search-result-list-web-result-description">
            {props.DescriptionLongWeBSearch}
          </span>
        </div>
        <div className="web-search-result-list-web-result-share-icon-div">
          <img
            alt={props.image_alt}
            src={props.image_src}
            className="web-search-result-list-share-icon"
          />
        </div>
      </div>
    </div>
  )
}

WebSearchResultList.defaultProps = {
  DescriptionWebSearch: 'Serie A - Wikipedia',
  rootClassName: '',
  image_alt: 'image',
  DescriptionLongWeBSearch:
    "10 ore fa — Il Campionato di Serie A, colloquialmente abbreviato in Serie A e ufficialmente denominato Serie A TIM dall'edizione 1998-1999 per ragioni di ...",
  image_src: '/playground_assets/share.1%203.svg',
  LinkWebSearch1: 'https://it.wikipedia.org › wiki › Serie_A',
}

WebSearchResultList.propTypes = {
  DescriptionWebSearch: PropTypes.string,
  rootClassName: PropTypes.string,
  image_alt: PropTypes.string,
  DescriptionLongWeBSearch: PropTypes.string,
  image_src: PropTypes.string,
  LinkWebSearch1: PropTypes.string,
}

export default WebSearchResultList
