import React from 'react'

import PropTypes from 'prop-types'

import './profile-side.css'

const ProfileSide = (props) => {
  return (
    <div className={`profile-side-container ${props.rootClassName} `}>
      <div className="profile-side-profile-name-div">
        <span className="profile-side-name-surname">{props.ProfileName}</span>
        <span className="profile-side-username">{props.ProfileName1}</span>
      </div>
      <div className="profile-side-profile-pic"></div>
    </div>
  )
}

ProfileSide.defaultProps = {
  ProfileName: 'Andrea Beneventi',
  ProfileName1: '@andreabeneventi12',
  rootClassName: '',
}

ProfileSide.propTypes = {
  ProfileName: PropTypes.string,
  ProfileName1: PropTypes.string,
  rootClassName: PropTypes.string,
}

export default ProfileSide
