import React from 'react'

import PropTypes from 'prop-types'

import './news-filter.css'

const NewsFilter = (props) => {
  return (
    <div className={`news-filter-group74 ${props.rootClassName} `}>
      <div className="news-filter-frame4">
        <span className="news-filter-text">
          <span>Categorie</span>
        </span>
        <img
          alt="Vector29830"
          src="/playground_assets/vector29830-4ko.svg"
          className="news-filter-vector2"
        />
      </div>
      <span className="news-filter-text02">
        <span>Reset filtri</span>
      </span>
      <div className="news-filter-frame1">
        <span className="news-filter-text04">
          <span>Data</span>
        </span>
        <img
          alt="Vector21071"
          src="/playground_assets/vector21071-vclq.svg"
          className="news-filter-vector21"
        />
      </div>
      <div className="news-filter-frame2">
        <span className="news-filter-text06">
          <span>Lingue</span>
        </span>
        <img
          alt="Vector21071"
          src="/playground_assets/vector21071-odt2w.svg"
          className="news-filter-vector22"
        />
      </div>
      <span className="news-filter-text08">
        <span>Ricerca solo dalle tue fonti</span>
      </span>
      <div className="news-filter-group23">
        <img
          alt="Rectangle61I175"
          src="/playground_assets/rectangle61i175-7f2j-200h.png"
          className="news-filter-rectangle61"
        />
        <img
          alt="Ellipse2I175"
          src="/playground_assets/ellipse2i175-fweh-200w.png"
          className="news-filter-ellipse2"
        />
      </div>
    </div>
  )
}

NewsFilter.defaultProps = {
  rootClassName: '',
}

NewsFilter.propTypes = {
  rootClassName: PropTypes.string,
}

export default NewsFilter
