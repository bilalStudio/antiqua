import React from 'react'

import { Helmet } from 'react-helmet'

import './home.css'

const Home = (props) => {
  return (
    <div className="home-container">
      <Helmet>
        <title>Home - Weagle</title>
        <meta property="og:title" content="Home - Weagle" />
      </Helmet>
    </div>
  )
}

export default Home
