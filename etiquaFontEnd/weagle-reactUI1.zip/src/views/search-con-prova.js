import React from 'react'

import { Helmet } from 'react-helmet'

import SideBar from '../components/side-bar'
import SearchBar1 from '../components/search-bar1'
import './search-con-prova.css'

const SearchConProva = (props) => {
  return (
    <div className="search-con-prova-container">
      <Helmet>
        <title>Weagle</title>
        <meta property="og:title" content="Weagle" />
      </Helmet>
      <div className="search-con-prova-container-principale">
        <div className="search-con-prova-container1">
          <SideBar rootClassName="side-bar-root-class-name"></SideBar>
        </div>
        <div className="search-con-prova-container2">
          <span className="search-con-prova-text">
            <span>Accedi al servizio</span>
            <br></br>
          </span>
        </div>
      </div>
      <div className="search-con-prova-naviga-trapiu-div">
        <div className="search-con-prova-naviga-trapiu-div-c1">
          <h1 className="search-con-prova-text03">
            <span>Naviga tra più motori di ricerca</span>
            <br></br>
            <span>grazie al Power Search</span>
          </h1>
        </div>
        <SearchBar1></SearchBar1>
      </div>
      <span className="search-con-prova-demoresearchp">
        1 ricerca demo disponibile
      </span>
      <div className="search-con-prova-iconsdiv">
        <div className="search-con-prova-feature1">
          <img
            alt="image"
            src="/playground_assets/shield-user-protection%201.svg"
            className="search-con-prova-image"
          />
          <span className="search-con-prova-text07">
            Proteggi i tuoi dati di navigazione all&apos;interno del tuo Data
            Wallet
          </span>
        </div>
        <div className="search-con-prova-feature2">
          <img
            alt="image"
            src="/playground_assets/earth%2C%20home%2C%20world%201.svg"
            className="search-con-prova-image1"
          />
          <span className="search-con-prova-text08">
            Ricerche professionali più semplici e performanti grazie agli
            innovativi tools di navigazione del Power Search
          </span>
        </div>
        <div className="search-con-prova-feature3">
          <img
            alt="image"
            src="/playground_assets/password-edit-protection%201.svg"
            className="search-con-prova-image2"
          />
          <span className="search-con-prova-text09">
            Elimina, archivia e scopri come monetizzare i dati generati dalla
            tua navigazione
            <span
              dangerouslySetInnerHTML={{
                __html: ' ',
              }}
            />
          </span>
        </div>
      </div>
    </div>
  )
}

export default SearchConProva
