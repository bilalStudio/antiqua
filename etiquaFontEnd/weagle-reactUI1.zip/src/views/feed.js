import React from 'react'

import { Helmet } from 'react-helmet'

import SideBar from '../components/side-bar'
import SearchBar1 from '../components/search-bar1'
import ProfileSide from '../components/profile-side'
import FeedPreview from '../components/feed-preview'
import './feed.css'

const Feed = (props) => {
  return (
    <div className="feed-container">
      <Helmet>
        <title>Feed - Weagle</title>
        <meta property="og:title" content="Feed - Weagle" />
      </Helmet>
      <div className="feed-container-principale">
        <div className="feed-container1">
          <SideBar rootClassName="side-bar-root-class-name1"></SideBar>
        </div>
        <SearchBar1 rootClassName="search-bar1-root-class-name1"></SearchBar1>
        <ProfileSide rootClassName="profile-side-root-class-name"></ProfileSide>
      </div>
      <div className="feed-container2">
        <FeedPreview rootClassName="feed-preview-root-class-name"></FeedPreview>
        <div className="feed-container3">
          <span className="feed-text">Vai al mio Feed &gt;</span>
        </div>
        <div className="feed-container4">
          <div className="feed-container5">
            <img
              alt="image"
              src="/playground_assets/shield-user-protection%201%20%5B1%5D.svg"
              className="feed-image"
            />
            <span className="feed-text1">
              Proteggi i tuoi dati di navigazione all&apos;interno del tuo Data
              Wallet
            </span>
          </div>
          <div className="feed-container6">
            <img
              alt="image"
              src="/playground_assets/group.svg"
              className="feed-image1"
            />
            <span className="feed-text2">
              Ricerche professionali più semplici e performanti grazie agli
              innovativi tools di navigazione del Power Search
            </span>
          </div>
          <div className="feed-container7">
            <img
              alt="image"
              src="/playground_assets/password-edit-protection%201%20%5B1%5D.svg"
              className="feed-image2"
            />
            <span className="feed-text3">
              Elimina, archivia e scopri come monetizzare i dati generati dalla
              tua navigazione
              <span
                dangerouslySetInnerHTML={{
                  __html: ' ',
                }}
              />
            </span>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Feed
