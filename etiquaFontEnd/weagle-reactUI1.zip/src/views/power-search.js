import React from 'react'

import { Helmet } from 'react-helmet'

import SideBar from '../components/side-bar'
import SearchBar1 from '../components/search-bar1'
import ProfileSide from '../components/profile-side'
import TabPowerSearch from '../components/tab-power-search'
import SearchEngineSelection from '../components/search-engine-selection'
import WebSearchResultList from '../components/web-search-result-list'
import './power-search.css'

const PowerSearch = (props) => {
  return (
    <div className="power-search-container">
      <Helmet>
        <title>PowerSearch - Weagle</title>
        <meta property="og:title" content="PowerSearch - Weagle" />
      </Helmet>
      <div className="power-search-container-principale">
        <div className="power-search-container1">
          <SideBar rootClassName="side-bar-root-class-name2"></SideBar>
        </div>
        <div className="power-search-container2">
          <SearchBar1 rootClassName="search-bar1-root-class-name"></SearchBar1>
        </div>
        <ProfileSide rootClassName="profile-side-root-class-name1"></ProfileSide>
      </div>
      <div className="power-search-tabs-filters-div">
        <TabPowerSearch rootClassName="tab-power-search-root-class-name"></TabPowerSearch>
        <SearchEngineSelection rootClassName="search-engine-selection-root-class-name"></SearchEngineSelection>
      </div>
      <div className="power-search-results-div">
        <WebSearchResultList rootClassName="web-search-result-list-root-class-name"></WebSearchResultList>
        <WebSearchResultList rootClassName="web-search-result-list-root-class-name1"></WebSearchResultList>
        <WebSearchResultList rootClassName="web-search-result-list-root-class-name3"></WebSearchResultList>
        <WebSearchResultList rootClassName="web-search-result-list-root-class-name2"></WebSearchResultList>
      </div>
    </div>
  )
}

export default PowerSearch
